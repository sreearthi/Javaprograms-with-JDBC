


package com.examplegavs.helloworldsample.helloworldcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examplegavs.helloworldsample.helloworldservice.hwService;

@RestController
@RequestMapping("/run")
public class hwController {
	
	@Autowired
	hwService hwservice;

	@GetMapping("/hello")
	public String run() {
		return hwservice.hello();
	}
	
	@GetMapping("/test")
	public String show() {
		return "hello Infotel";
	}

}


