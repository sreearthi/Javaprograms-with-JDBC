package com.examplegavs.helloworldsample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloWorldSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloWorldSampleApplication.class, args);
		System.out.println("hai how are u");
	}

}
