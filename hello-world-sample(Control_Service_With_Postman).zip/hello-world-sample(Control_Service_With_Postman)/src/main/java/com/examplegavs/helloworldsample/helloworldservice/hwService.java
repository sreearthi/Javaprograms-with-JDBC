package com.examplegavs.helloworldsample.helloworldservice;

import org.springframework.stereotype.Service;

@Service
public class hwService {
	
	public String hello() {
		return "Hello World";
	}
	

}
