package com.examplegavs.helloworldsample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloWorldSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
