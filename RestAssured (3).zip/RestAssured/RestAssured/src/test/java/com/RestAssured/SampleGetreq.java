package com.RestAssured;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class SampleGetreq {

	public static void main(String[] args) {
		//create a request specification
		RequestSpecification request=RestAssured.given();
		
		//Adding URI
		request.baseUri("https://reqres.in/api/users?page=2");//localhost:8087/evoz/listcount
		
		//call get method on the URI
		Response response=request.get();
		
		//print response body
		String resString=response.asString();
		
		System.out.println(resString);
		
		//to perform validation on the response
		
		ValidatableResponse valres=response.then();
		
		valres.statusCode(200);
		
	}
}
