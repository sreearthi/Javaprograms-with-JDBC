package com.RestAssured;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import org.json.simple.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

public class ConvertPojoToJson {

	
	@Test
	public void test_APIwithbasicauthentication() {
		given().auth().preemptive().basic("username","password").
		when().get("https://postman-echo.com/basic-auth/").
		then().assertThat().statusCode(401);
	}
	

}
