package com.RestAssured;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import org.json.simple.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

public class QueryandPathparameter {

	
	@Test
	public void test_MDChecksumoftest() {
		String originaltext="test";
		String expectedMD5CheckSum="098f6bcd4621d373cade4e832627b4f6";
		
		given().param("text", originaltext).
		when().get("http://md5.jsontest.com/").
		then().assertThat().body("md5", equalTo(expectedMD5CheckSum));
	}
	

	@Test(dataProvider = "seasonsandNumberofraces")
		public void test_Numberofcircuits(String season,int numberOfRaces) {
		given().pathParam("raceSeason", season).
		when().get("https://ergast.com/api/f1/{raceSeason}/circuits.json").// retrive the data//localhost:8087/evoz/listusers?pageNo=1
		//retrive the data in page total
		//localhost:8087/evoz/listcount
		then().assertThat().body("MRData.CircuitTable.Circuits.circuitId",hasSize(numberOfRaces) );
	}
	
	@DataProvider(name = "seasonsandNumberofraces")
	public Object[][] createTestDataRecords(){
		return new Object[][] {
			{"2017",20},
			{"2016",21},
			{"1966",9}
		};
	}
}
