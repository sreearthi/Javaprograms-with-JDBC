package com.RestAssured;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ConvertPojoToJson {

	public static void main(String[] args) throws JsonProcessingException {
		//create object of pojo and set values
		Person person=new Person();
		person.setName("priya");
		person.setAge(22);
		//objectmapper class to serialize pojo object to json
		ObjectMapper objectmapper=new ObjectMapper();
		String json=objectmapper.writerWithDefaultPrettyPrinter().writeValueAsString(person);
		System.out.println(json);

	}

}
