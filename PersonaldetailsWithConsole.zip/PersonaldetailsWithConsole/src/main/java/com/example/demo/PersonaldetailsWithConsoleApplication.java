package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonaldetailsWithConsoleApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonaldetailsWithConsoleApplication.class, args);
		System.out.println("Name:P.Sivaranjani");
		System.out.println("Father NAme : J.Parthiban ");
		System.out.println("Mother Name: P.Parameshwari");
		System.out.println("DOB:25-05-2001");
	}

}
