package Java;
import java.util.Scanner;
public class Exception5{  
   static void validate(int employeeAge)
   {  
     if(employeeAge <= 20)  						//45     15
      throw new ArithmeticException("Not valid");  //<15>
     else  
      System.out.println("Welcome to CTS");  //<45>
   }  
   
   public static void main(String args[]){  
	   Scanner sc = new Scanner(System.in);
	   System.out.println("Enter your age : ");
	   int employeeAge = sc.nextInt();
	   try {
		   validate(employeeAge);
	   }
	   catch(Exception e)
	   { System.out.println(e);	}
	   
      System.out.println("Execution over");  
  }  
} 
