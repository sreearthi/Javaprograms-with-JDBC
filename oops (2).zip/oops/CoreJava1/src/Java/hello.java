package Java;

public class hello {

	public static void main(String[] args) {
		System.out.println("hai welcome to java");
		System.out.println("hello welcome to java");
		System.out.println("hai welcome to java");
		System.out.println("hello welcome to java");

	}

}
