package Java;

public class hai {

	public static void main(String[] args) {
		System.out.println("hai");
	}

}
