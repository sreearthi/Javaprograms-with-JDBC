package Java;
import java.util.*;
class Javaframe{
public static void main(String args[]){
 
ArrayList al=new ArrayList();  // creating array list
al.add("sathyapriya and yathul");                // adding elements    
al.add("pachanan and harsha");
Iterator itr=al.iterator();
while(itr.hasNext()){
System.out.println(itr.next());
}
}
}