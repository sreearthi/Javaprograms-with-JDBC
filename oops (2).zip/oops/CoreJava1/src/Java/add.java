package Java;

public class add {

	public static void main(String[] args) {
		int a,b,c,d,f,e;//TO DEFINE DATATYPE INTERGER AND VARIBLES A,B,C
		a=10;b=20;
		c=a+b;//addition
		d=a-b;//sub
		e=a*b;//mul
		f=b/a;//div
		System.out.println("enter the values c is addition:"+c);// add function to mension the variable C
		System.out.println("enter the values d is sub :"+d);
		System.out.println("enter the values e is multiplication:"+e);
		System.out.println("enter the values f is division :"+f);
	}

}
