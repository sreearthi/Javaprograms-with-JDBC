package Java;
public class ImplementsS implements InterfaceS, InterfaceS1{
	
	public void print()
	{
		System.out.println("Welcome...");
	}

	
	public void print1() {
		System.out.println("To Java...");
	}
	
}
