
public class StringParser {

	public static void main(String[] args) {
		String s = "abcd";
		int i = Integer.parseInt(s);

	}

}
