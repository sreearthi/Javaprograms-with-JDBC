
public class ThrowKeyword {

	public static void main(String[] args) {
		
		try{
		throw new Exception("Funds not available");
		}
		catch(Exception e){
			
		}

	}

}
