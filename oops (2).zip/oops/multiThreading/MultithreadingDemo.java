package multiThreading;
class MultithreadingDemo implements Runnable 
{
	public void run()
	{
		try {
			// Displaying the thread that is running
			System.out.println( "Thread " + Thread.currentThread()
			+ " is running");
		}
		catch (Exception e) 
		{
			// Throwing an exception
			System.out.println("Exception is caught");
		}
	}
	public static void main(String[] args)  {
		MultithreadingDemo thread = new MultithreadingDemo();
		MultithreadingDemo thread2 = new MultithreadingDemo();
		thread.run();

		thread2.run();
	}
	
}
