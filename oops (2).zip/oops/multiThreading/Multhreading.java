package multiThreading;

public class Multhreading extends Thread {
public Multhreading(String string) {
		// TODO Auto-generated constructor stub
	System.out.println(string);
	}

public static void main(String[] args) throws InterruptedException {
	Multhreading multi = new Multhreading("Siva");
	Multhreading multis = new Multhreading("Sivas");
	multi.start();
	multis.join(5000);
	//multis.start();
}
}
