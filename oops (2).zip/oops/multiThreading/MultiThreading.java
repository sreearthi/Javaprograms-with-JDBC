package multiThreading;

import java.util.Scanner;

public class MultiThreading extends MultiThreading2 {
	Scanner scan =new Scanner(System.in);
	private int balance;

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	
public void run() {
	int Withdrawal=150;
		balance=1000000;
		int totalBalances = balance - Withdrawal;
		System.out.println("Your Account Balance IS " + totalBalances);

}
}