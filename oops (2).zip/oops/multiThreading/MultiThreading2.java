package multiThreading;


public class MultiThreading2 extends Thread {
	public static void main(String args[]) {
		MultiThreading obj = new MultiThreading();
		MultiThreading thread=new MultiThreading();
		MultiThreading thread2=new MultiThreading();
		thread.start();
	//	thread.setPriority(MAX_PRIORITY);
		//thread2.interrupt();
		thread2.start();
		if(thread2.isInterrupted()==true) {
			System.out.println("You Cannot Withdraw");
		}
	}
}