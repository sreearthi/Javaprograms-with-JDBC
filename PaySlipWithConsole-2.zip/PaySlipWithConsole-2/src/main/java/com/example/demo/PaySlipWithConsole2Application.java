package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaySlipWithConsole2Application {

	public static void main(String[] args) {
		SpringApplication.run(PaySlipWithConsole2Application.class, args);
		System.out.println("                         			 SMURK IT INDIA                                ");
		System.out.println("              		     	 Ramanujam It Park ,Taramani,TamilNadu -600113");
		System.out.println("________________________________________________________________________________________________________________________________________________________");
		
			System.out.println("PayRoll FOr The Month OF January 2023");
			System.out.println("____________________________________________________________________________________________________________________________________________________");
			
		System.out.println("Employee Name            : Sivaranjani Parthiban");
		System.out.println("Employee Code            : 100068");
		System.out.println("Pan Number               : GYIPP28082H");
		System.out.println("Total No Of Working Days : 22                           Total Number of days Worked : 22");
		System.out.println("Basic Pay                : 12500");
		System.out.println("House Rent Allowance     : 6250");
		System.out.println("Telephone Allowance      : 1250");
		System.out.println("FoodCoupons              : 1250");
		System.out.println("Flexi Pay                : 25000");
		System.out.println("Special Allowance        : 1250 ");
		
		System.out.println("________________________________________________________________________________________________________________________________________________________");
		
		System.out.println("Gross salary : 25000                                     Gross Deduction :200");
		
		System.out.println("\nNetSalary: 24,800");
		System.out.println("________________________________________________________________________________________________________________________________________________________");
		System.out.println("This Is a System Generated Payslip Does Not Require Signature . ");
	}

}
